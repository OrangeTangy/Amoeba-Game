import React, { useEffect, useMemo, useState } from 'react';
import { socket } from './socket';

const STATES = {
  LOBBY: 'LOBBY',
  PROMPT_SUBMIT: 'PROMPT_SUBMIT',
  ANSWER_SUBMIT: 'ANSWER_SUBMIT',
  REVEAL: 'REVEAL',
  GUESSING: 'GUESSING',
  ROUND_END: 'ROUND_END',
};

export default function App(){
  const [connected, setConnected] = useState(false);
  const [roomId, setRoomId] = useState('');
  const [name, setName] = useState('');
  const [me, setMe] = useState({ id:null, hostId:null });
  const [snap, setSnap] = useState(null);
  const [promptText, setPromptText] = useState('');
  const [answerText, setAnswerText] = useState('');
  const [selectedAnswerId, setSelectedAnswerId] = useState(null);
  const [accusedId, setAccusedId] = useState(null);
  const [answersRevealed, setAnswersRevealed] = useState([]);
  const [log, setLog] = useState([]);

  useEffect(() => {
    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('room:state', (s) => setSnap(s));
    socket.on('answers:revealed', ({ answers }) => setAnswersRevealed(answers));
    socket.on('turn:changed', ({ currentTurnPlayerId }) => {
      setLog(l => [{ t:'turn', id: currentTurnPlayerId, ts: Date.now() }, ...l].slice(0,50));
    });
    socket.on('guess:result', (m) => {
      setLog(l => [{ t:'guess', ...m, ts: Date.now() }, ...l].slice(0,50));
    });
    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('room:state');
      socket.off('answers:revealed');
      socket.off('turn:changed');
      socket.off('guess:result');
    };
  }, []);

  const amHost = snap && me.id && snap.hostId === me.id;
  const myPlayer = useMemo(() => snap?.players?.find(p => p.id === me.id), [snap, me.id]);

  function join(){
    if (!name) return alert('Enter a name');
    socket.connect();
    socket.emit('room:join', { roomId: roomId.trim(), name: name.trim() }, (ack) => {
      if (!ack?.ok) return alert(ack?.error || 'Join failed');
      setRoomId(ack.roomId);
      setMe({ id: ack.playerId, hostId: ack.hostId });
    });
  }

  function startGame(){ socket.emit('room:start'); }
  function submitPrompt(){ if (promptText) { socket.emit('prompt:submit', { text: promptText }); setPromptText(''); } }
  function submitAnswer(){ if (answerText) { socket.emit('answer:submit', { text: answerText }); setAnswerText(''); } }
  function submitGuess(){
    if (!selectedAnswerId || !accusedId) return;
    socket.emit('guess:submit', { answerId: selectedAnswerId, accusedPlayerId: accusedId });
    setSelectedAnswerId(null); setAccusedId(null);
  }
  function nextRound(){ socket.emit('round:next'); }

  return (
    <div className="container">
      <div className="header">
        <div>
          <h1>Amoeba</h1>
          <div className="small">Room: <strong>{roomId || '—'}</strong></div>
        </div>
        <div className="small">{connected ? '🟢 connected' : '🔴 disconnected'}</div>
      </div>

      {!snap && (
        <div className="card">
          <h2>Join a Room</h2>
          <div className="row" style={{alignItems:'center'}}>
            <input className="input" placeholder="Your name" value={name} onChange={e=>setName(e.target.value)} />
            <input className="input" placeholder="Room code (or empty to create)" value={roomId} onChange={e=>setRoomId(e.target.value.toUpperCase())} />
            <button className="btn" onClick={join}>Join</button>
          </div>
        </div>
      )}

      {snap && (
        <div className="row">
          <div style={{flex:1, minWidth: 320}}>
            <div className="card">
              <h3>Players</h3>
              <div className="row">
                {snap.players?.map(p => (
                  <div key={p.id} className="team">
                    <div><strong>{p.name}</strong> {p.id===snap.hostId && <span className="badge">Host</span>}</div>
                    <div className="small">Team: {p.teamId?.slice(0,6) || '—'}</div>
                    <div className="small">{p.connected ? '🟢' : '🔴'}</div>
                  </div>
                ))}
              </div>
              <hr/>
              {snap.state === 'LOBBY' && (
                <div>
                  <div className="small">Waiting in lobby…</div>
                  {amHost && <button className="btn" onClick={startGame}>Start Game</button>}
                </div>
              )}
            </div>

            <div className="card" style={{marginTop:12}}>
              <h3>Events</h3>
              <div className="small">
                {log.map((e,i)=>(
                  <div key={i}>
                    {e.t==='turn' && <div>Turn → <strong>{snap.players?.find(p=>p.id===e.id)?.name || e.id}</strong></div>}
                    {e.t==='guess' && <div>
                      Guess: {snap.players?.find(p=>p.id===e.capturingPlayerId)?.name} → {snap.players?.find(p=>p.id===e.accusedPlayerId)?.name} | {e.correct? '✅ CORRECT' : '❌ WRONG'}
                    </div>}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div style={{flex:2, minWidth: 420}}>
            {snap.state === STATES.PROMPT_SUBMIT && (
              <div className="card">
                <h2>Submit a Prompt</h2>
                <div className="small">Example: "What would your final words be?"</div>
                <div className="row" style={{marginTop:8}}>
                  <input className="input" style={{flex:1}} maxLength={140} value={promptText} onChange={e=>setPromptText(e.target.value)} placeholder="Your prompt…" />
                  <button className="btn" onClick={submitPrompt}>Submit</button>
                </div>
              </div>
            )}

            {snap.state === STATES.ANSWER_SUBMIT && (
              <div className="card">
                <h2>Answer the Prompt</h2>
                <div className="small">Prompt: <strong>{snap.activePrompt}</strong></div>
                <div className="row" style={{marginTop:8}}>
                  <input className="input" style={{flex:1}} maxLength={140} value={answerText} onChange={e=>setAnswerText(e.target.value)} placeholder="Your answer…" />
                  <button className="btn" onClick={submitAnswer}>Submit</button>
                </div>
              </div>
            )}

            {(snap.state === STATES.REVEAL || snap.state === STATES.GUESSING) && (
              <div className="card">
                <h2>Answers</h2>
                <div className="small">Prompt: <strong>{snap.activePrompt}</strong></div>
                <div className="small">Turn: <strong>{snap.players?.find(p=>p.id===snap.currentTurnPlayerId)?.name || '—'}</strong></div>
                <div className="grid" style={{marginTop:10}}>
                  { (snap.answers || []).map(a => {
                    const revealed = answersRevealed.find(x => x.id === a.id);
                    if (!revealed) return null;
                    const claimed = a.claimedByTeamId;
                    return (
                      <div key={a.id} className={`answer ${claimed?'claimed':''}`} onClick={()=>setSelectedAnswerId(a.id)}>
                        <div>{revealed.text}</div>
                        {selectedAnswerId===a.id && <div className="small">Selected</div>}
                        {claimed && <div className="small">Claimed</div>}
                      </div>
                    );
                  })}
                </div>
                {myPlayer && snap.state === STATES.GUESSING && snap.currentTurnPlayerId === myPlayer.id && (
                  <div className="row" style={{marginTop:10, alignItems:'center'}}>
                    <select className="input" value={accusedId||''} onChange={e=>setAccusedId(e.target.value)}>
                      <option value="">Pick username…</option>
                      {snap.players?.map(p => (<option key={p.id} value={p.id}>{p.name}</option>))}
                    </select>
                    <button className="btn" disabled={!selectedAnswerId || !accusedId} onClick={submitGuess}>Guess</button>
                  </div>
                )}
              </div>
            )}

            {snap.state === STATES.ROUND_END && (
              <div className="card">
                <h2>Round Over</h2>
                <button className="btn" onClick={nextRound}>Next Round</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
