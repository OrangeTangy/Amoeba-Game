import { io } from 'socket.io-client';

// Configure this via environment variable when building for production:
const SERVER_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:4000';

export const socket = io(SERVER_URL, { transports: ['websocket'], autoConnect: false });
