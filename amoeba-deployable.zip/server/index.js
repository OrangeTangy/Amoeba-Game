import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const PORT = process.env.PORT || 4000;
const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

app.get('/', (req, res) => res.json({ ok: true, service: 'amoeba-server' }));

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*', // tighten in production
    methods: ['GET', 'POST']
  }
});

const STATES = {
  LOBBY: 'LOBBY',
  PROMPT_SUBMIT: 'PROMPT_SUBMIT',
  ANSWER_SUBMIT: 'ANSWER_SUBMIT',
  REVEAL: 'REVEAL',
  GUESSING: 'GUESSING',
  ROUND_END: 'ROUND_END',
};

const PHASE_DURATIONS = {
  PROMPT_SUBMIT: 45000,
  ANSWER_SUBMIT: 60000,
};

const rooms = new Map();

function makeRoom(roomId) {
  return {
    id: roomId,
    state: STATES.LOBBY,
    hostId: null,
    roundNumber: 1,
    players: new Map(),
    teams: new Map(),
    prompts: [],
    answers: [],
    activePrompt: null,
    currentTurnPlayerId: null,
    timers: {},
  };
}

function nanoid(n=8){ const s='ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let out=''; for(let i=0;i<n;i++) out+=s[Math.floor(Math.random()*s.length)]; return out; }

function serializeRoom(room) {
  return {
    id: room.id,
    state: room.state,
    hostId: room.hostId,
    roundNumber: room.roundNumber,
    players: Array.from(room.players.values()).map(p => ({ id:p.id, name:p.name, connected:p.connected, teamId:p.teamId, isTeamLead:p.isTeamLead })),
    teams: Array.from(room.teams.values()).map(t => ({ id:t.id, leadId:t.leadId, memberIds:t.memberIds })),
    activePrompt: room.activePrompt,
    answers: room.answers.map(a => ({ id:a.id, text:a.text, claimedByTeamId:a.claimedByTeamId })),
    currentTurnPlayerId: room.currentTurnPlayerId,
  };
}

function emitState(room) {
  io.to(room.id).emit('room:state', serializeRoom(room));
}

function clearTimers(room){
  for (const k of Object.keys(room.timers)) clearTimeout(room.timers[k]);
  room.timers = {};
}

function allSubmitted(list, players) {
  const submittedIds = new Set(list.map(x => x.playerId || x.authorId));
  for (const p of players.values()) {
    if (!submittedIds.has(p.id)) return false;
  }
  return true;
}

function ensureTeamsSolo(room){
  room.teams.clear();
  for (const p of room.players.values()) {
    const teamId = p.id;
    room.teams.set(teamId, { id: teamId, leadId: p.id, memberIds: [p.id] });
    p.teamId = teamId;
    p.isTeamLead = true;
  }
}

function mergePlayerIntoTeam(room, playerId, teamId) {
  const player = room.players.get(playerId);
  if (!player) return;
  const targetTeam = room.teams.get(teamId);
  if (!targetTeam) return;

  if (player.teamId && room.teams.has(player.teamId)) {
    const old = room.teams.get(player.teamId);
    old.memberIds = old.memberIds.filter(id => id !== playerId);
    if (old.memberIds.length === 0) room.teams.delete(old.id);
  }
  player.teamId = targetTeam.id;
  if (!targetTeam.memberIds.includes(playerId)) targetTeam.memberIds.push(playerId);
}

function allInOneTeam(room) {
  const aliveTeams = Array.from(room.teams.values()).filter(t => t.memberIds.length > 0);
  if (aliveTeams.length <= 1) return true;
  const left = room.answers.filter(a => !a.claimedByTeamId).length;
  if (left === 0) return true;
  return false;
}

function goto(room, state) {
  clearTimers(room);
  room.state = state;
  if (state === STATES.PROMPT_SUBMIT) {
    room.prompts = [];
    room.activePrompt = null;
    room.answers = [];
    room.currentTurnPlayerId = null;
    room.timers.prompt = setTimeout(() => pickPrompt(room), PHASE_DURATIONS.PROMPT_SUBMIT);
  }
  if (state === STATES.ANSWER_SUBMIT) {
    room.answers = [];
    room.timers.answer = setTimeout(() => revealAnswers(room), PHASE_DURATIONS.ANSWER_SUBMIT);
  }
  if (state === STATES.REVEAL) {
    ensureTeamsSolo(room);
    const ids = Array.from(room.players.keys());
    room.currentTurnPlayerId = ids[Math.floor(Math.random()*ids.length)];
    emitState(room);
    io.to(room.id).emit('answers:revealed', { answers: room.answers.map(a => ({ id:a.id, text:a.text })) });
    io.to(room.id).emit('turn:changed', { currentTurnPlayerId: room.currentTurnPlayerId });
    room.state = STATES.GUESSING;
  }
  if (state === STATES.ROUND_END) {
    const aliveTeams = Array.from(room.teams.values()).sort((a,b)=>b.memberIds.length - a.memberIds.length);
    const winningTeamId = aliveTeams[0]?.id || null;
    io.to(room.id).emit('round:ended', { winningTeamId });
  }
  emitState(room);
}

function pickPrompt(room) {
  if (room.state !== STATES.PROMPT_SUBMIT) return;
  if (room.prompts.length === 0) {
    room.activePrompt = "What would be your final words?";
  } else {
    const choice = room.prompts[Math.floor(Math.random() * room.prompts.length)];
    room.activePrompt = choice.text;
  }
  goto(room, STATES.ANSWER_SUBMIT);
}

function revealAnswers(room) {
  if (room.state !== STATES.ANSWER_SUBMIT) return;
  room.answers.sort(() => Math.random() - 0.5);
  goto(room, STATES.REVEAL);
}

io.on('connection', (socket) => {
  socket.on('room:join', ({ roomId, name }, ack) => {
    try {
      if (!roomId) roomId = nanoid(6);
      let room = rooms.get(roomId);
      if (!room) { room = makeRoom(roomId); rooms.set(roomId, room); }
      const player = {
        id: socket.id,
        name: String(name || 'Player').slice(0, 20),
        connected: true,
        teamId: null,
        isTeamLead: false,
      };
      room.players.set(socket.id, player);
      if (!room.hostId) room.hostId = socket.id;
      socket.join(roomId);
      emitState(room);
      ack && ack({ ok:true, roomId, playerId: socket.id, hostId: room.hostId });
    } catch (e) {
      ack && ack({ ok:false, error: e.message });
    }
  });

  socket.on('room:start', () => {
    const room = findRoomBySocket(socket);
    if (!room) return;
    if (room.hostId !== socket.id) return;
    room.roundNumber += (room.state === STATES.LOBBY ? 0 : 1);
    goto(room, STATES.PROMPT_SUBMIT);
  });

  socket.on('prompt:submit', ({ text }) => {
    const room = findRoomBySocket(socket);
    if (!room || room.state !== STATES.PROMPT_SUBMIT) return;
    const t = ('' + (text || '')).trim().slice(0, 140);
    if (!t) return;
    if (room.prompts.some(p => p.playerId === socket.id)) return;
    room.prompts.push({ playerId: socket.id, text: t });
    emitState(room);
    if (allSubmitted(room.prompts, room.players)) pickPrompt(room);
  });

  socket.on('answer:submit', ({ text }) => {
    const room = findRoomBySocket(socket);
    if (!room || room.state !== STATES.ANSWER_SUBMIT) return;
    const t = ('' + (text || '')).trim().slice(0, 140);
    if (!t) return;
    if (room.answers.some(a => a.authorId === socket.id)) return;
    room.answers.push({ id: nanoid(8), text: t, authorId: socket.id, claimedByTeamId: null });
    emitState(room);
    if (allSubmitted(room.answers, room.players)) revealAnswers(room);
  });

  socket.on('guess:submit', ({ answerId, accusedPlayerId }) => {
    const room = findRoomBySocket(socket);
    if (!room || room.state !== STATES.GUESSING) return;
    if (room.currentTurnPlayerId !== socket.id) return;
    const ans = room.answers.find(a => a.id === answerId);
    if (!ans || ans.claimedByTeamId) return;
    const authorId = ans.authorId;
    const correct = (accusedPlayerId === authorId);
    if (correct) {
      const captor = room.players.get(socket.id);
      if (!captor || !captor.teamId) return;
      ans.claimedByTeamId = captor.teamId;
      mergePlayerIntoTeam(room, authorId, captor.teamId);
      io.to(room.id).emit('guess:result', { correct:true, answerId, authorId, accusedPlayerId, capturingPlayerId: socket.id, teams: serializeRoom(room).teams });
      emitState(room);
      if (allInOneTeam(room)) return goto(room, STATES.ROUND_END);
    } else {
      room.currentTurnPlayerId = accusedPlayerId;
      io.to(room.id).emit('guess:result', { correct:false, answerId, authorId, accusedPlayerId, capturingPlayerId: socket.id, teams: serializeRoom(room).teams });
      io.to(room.id).emit('turn:changed', { currentTurnPlayerId: room.currentTurnPlayerId });
      emitState(room);
    }
  });

  socket.on('round:next', () => {
    const room = findRoomBySocket(socket);
    if (!room) return;
    if (room.state !== STATES.ROUND_END) return;
    goto(room, STATES.PROMPT_SUBMIT);
  });

  socket.on('disconnect', () => {
    const room = findRoomBySocket(socket);
    if (!room) return;
    const p = room.players.get(socket.id);
    if (p) p.connected = false;
    if (room.currentTurnPlayerId === socket.id) {
      const alive = Array.from(room.players.values()).filter(x => x.connected);
      if (alive.length > 0) {
        room.currentTurnPlayerId = alive[Math.floor(Math.random() * alive.length)].id;
        io.to(room.id).emit('turn:changed', { currentTurnPlayerId: room.currentTurnPlayerId });
      }
    }
    if (room.hostId === socket.id) {
      const still = Array.from(room.players.values()).find(x => x.connected);
      if (still) room.hostId = still.id;
    }
    emitState(room);
  });
});

function findRoomBySocket(socket){
  const roomsOfSocket = [...socket.rooms].filter(r => r !== socket.id);
  for (const roomId of roomsOfSocket) {
    const room = rooms.get(roomId);
    if (room) return room;
  }
  return null;
}

server.listen(PORT, () => {
  console.log(`[amoeba] server on :${PORT}`);
});
